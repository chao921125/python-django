# 项目开发
```shell
python -m pip install Django

# 查看版本
python3 -m django --version
# 启动
python3 manage.py runserver 0.0.0.0:8000
```
